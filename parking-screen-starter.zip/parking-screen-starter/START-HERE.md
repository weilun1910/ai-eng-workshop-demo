# Start here

In this exercise you design a parking screen for a car, and an AI coding agent builds it. Use whichever agent you prefer, like Codex or Claude Code. You're the architect. You decide what the screen has to do and how well it has to work. The agent writes the code.

## What's in this folder

- `REQUIREMENTS.md` is where you plan your screen. You fill it in, and the agent builds from it.
- `sensor.js` pretends to be the car's rear parking sensor. It plays back a recorded parking run and sends your page a new distance reading five times a second. Don't change it.
- `data.js` is that recorded run. Don't change it either.
- `sounds/` has two sounds you can use. `beep.wav` is a short parking beep, and `sensor-lost.wav` is for when the sensor misses.
- `sensor-test.html` checks that the setup works on your laptop.
- `AGENTS.md` gives the agent a few ground rules for this folder. Codex and many other agents read it on their own. `CLAUDE.md` just points Claude Code to it. You don't need to open either.

## Steps

You have about 15 minutes. A working first version is the goal today.

1. Open this folder in your agent, like Codex in the ChatGPT app. If it asks you to sign in or allow access, do it now, so it doesn't hold up your build later. (1 min)
2. Open `REQUIREMENTS.md`. The goal is already written for you. Write three functional requirements, one each for Logic, Display and Sound, each with a why. (4 min)
3. Write three non-functional requirements, one each for Safety, Performance and Visuals, each with a why. (3 min)
4. Paste the build prompt from the bottom of this file into your agent. (4 min)
5. Double-click the page the agent built and press its start button. Go through your requirements one at a time and mark each one passed or failed in section 4. The agent also lists the choices it made for you, so check those too. (2 min)

## Filling in REQUIREMENTS.md

You can type into the table rows, between the `|` marks, or just write plain sentences under each heading. Either works, because the agent tidies them into the rows before it builds. If your editor shows a formatted preview, edit the plain text instead, since the preview is only for reading.

### 1. Goal

To save time, the goal is written for you. On a real project, writing it is your job, and it's the most important step.

Notice what it covers. It says who the screen is for and who would ship it. It says where it runs, what data goes in and what it has to achieve. A good goal already hints at half your requirements.

### 2. Functional requirements

These are what your screen does, meaning things you can see or hear happen. Write one for each group, and give it a reason in the Why column.

They're split into three groups:

- Logic is taking in the readings and working out what they mean. Your row should set the zone distances, like where red starts.
- Display is what the driver sees. Think about how the driver knows how close they are without reading a number.
- Sound is what the driver hears. Think about what they hear in each zone.

### 3. Non-functional requirements

These are how well it has to work, and under what conditions. Write one for each group, and give it a reason in the Why column.

They're split into three groups:

- Safety is staying safe when things go wrong. For example, what the driver sees and hears when the sensor misses.
- Performance is being fast enough. For example, how quickly the screen and the sound react to a new reading.
- Visuals is how it looks. Describe it in a sentence or two, like the style, the colours and where things sit on the screen.

Here's a finished one under Performance, to show the idea:

| # | Requirement | Why |
|---|---|---|
| 2 | The beeping speeds up within 100 ms of the car entering a closer zone. | A driver needs information in real time to know when to stop. |

### 4. Check

Once it's built, go through your requirements one at a time and test each one on the page. For example, for a performance requirement, watch the moment the car crosses into red. Mark each one passed or failed. You don't need to fix anything today.

## What you should know about the sensor

Treat this like the datasheet for a real part. Your requirements have to fit these facts.

- A new reading arrives every 200 ms, so five a second. The whole run lasts 40 seconds.
- Each reading has `distance_cm`, the distance to the obstacle in centimetres. When the sensor misses, `distance_cm` is `NaN` and `missed` is `true`.
- Each reading also has `sentAt`, the moment it was sent. Compare it with `performance.now()` to measure how fast your screen reacts.
- The other fields, like `warning_level`, come from the Arduino in the hardware part. You can ignore them.
- Browsers won't play sound until the user clicks something on the page.
- Your page gets opened by double-clicking it, and a page opened that way can't load other files with `fetch`. Play the sounds with an audio element, for example `new Audio("sounds/beep.wav")`.

The full details are in the comment at the top of `sensor.js`.

## Prompts to start from

These are starting points. Change them to fit what you're asking.

To build:

```text
Read REQUIREMENTS.md and build the screen it describes as index.html in this folder. Get the readings from sensor.js and use the sounds in sounds/. Don't change sensor.js or data.js.
```

If you finish early and want to fix something, ask for one fix at a time:

```text
My screen fails my performance requirement. When the car crosses into red, the beeping takes about a second to speed up. What's causing it? Fix only that.
```
