# Parking screen requirements

## 1. Goal

Build a parking screen that a car manufacturer could put on their infotainment screen. It should be intuitive enough that a driver who glances at it while parking knows how close they are to the obstacle. It runs on distance readings from the car's rear parking sensor.

## 2. Functional requirements

### Logic


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 1   |                                          |                                          |




### Display


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 2   |                                          |                                          |




### Sound


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 3   |                                          |                                          |




## 3. Non-functional requirements

### Safety


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 1   |                                          |                                          |




### Performance


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 2   |                                          |                                          |




### Visuals


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 3   |                                          |                                          |




## 4. Check


| Requirement | Passed or failed | What I saw                               |
| ----------- | ---------------- | ---------------------------------------- |
|             |                  |                                          |
|             |                  |                                          |
|             |                  |                                          |
|             |                  |                                          |
|             |                  |                                          |
|             |                  |                                          |

