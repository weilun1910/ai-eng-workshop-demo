# Parking screen requirements

## 1. Goal

Build a parking screen that a car manufacturer could put on their infotainment screen. It should be intuitive enough that a driver who glances at it while parking knows how close they are to the obstacle. It runs on distance readings from the car's rear parking sensor.

## 2. Functional requirements

### Logic


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 1   |                                          |                                          |
| 2   |                                          |                                          |
| 3   |                                          |                                          |




### Display


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 4   |                                          |                                          |
| 5   |                                          |                                          |
| 6   |                                          |                                          |




### Sound


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 7   |                                          |                                          |
| 8   |                                          |                                          |
| 9   |                                          |                                          |




## 3. Non-functional requirements

### Usability


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 1   |                                          |                                          |
| 2   |                                          |                                          |




### Safety


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 3   |                                          |                                          |
| 4   |                                          |                                          |




### Performance


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 5   |                                          |                                          |
| 6   |                                          |                                          |




### Compatibility


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 7   |                                          |                                          |
| 8   |                                          |                                          |




### Visuals


| #   | Requirement                              | Why                                      |
| --- | ---------------------------------------- | ---------------------------------------- |
| 9   |                                          |                                          |
| 10  |                                          |                                          |




## 4. Check


| Requirement | Passed or failed | What I saw                               |
| ----------- | ---------------- | ---------------------------------------- |
|             |                  |                                          |
|             |                  |                                          |
|             |                  |                                          |

