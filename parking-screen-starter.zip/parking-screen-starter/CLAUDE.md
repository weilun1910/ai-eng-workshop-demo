# Ground rules for Claude Code

Follow the ground rules in AGENTS.md.

@AGENTS.md
