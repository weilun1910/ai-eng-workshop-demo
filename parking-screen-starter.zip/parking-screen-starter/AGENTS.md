# Ground rules for the AI coding agent in this folder

This folder is a classroom starter. A student is designing a rear parking screen for a car, and you're building it from their plan.

- Read `REQUIREMENTS.md` before you plan or write any code, and build what it says. If something in it is unclear or missing, ask the student. Don't fill the gap yourself.
- Don't change `sensor.js`, `data.js` or anything in `sounds/`. Together they stand in for the car's sensor.
- Get readings only through `sensor.onReading`, as described in the comment at the top of `sensor.js`.
- Keep every file you create in this folder.
