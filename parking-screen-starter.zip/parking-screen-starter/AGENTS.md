# Ground rules for the AI coding agent in this folder

This folder is a classroom starter. A student is designing a rear parking screen for a car, and you're building it from their plan.

- Read `REQUIREMENTS.md` before you plan or write any code, and build what it says.
- If the student wrote some requirements as plain sentences instead of in the table rows, tidy them into the right rows first. Keep their wording.
- If something is unclear or missing, don't stop to ask. Make a sensible choice and keep going. When you're done, list every choice you made that the student didn't write down, so they can check it.
- Don't change `sensor.js`, `data.js` or anything in `sounds/`. Together they stand in for the car's sensor.
- Get readings only through `sensor.onReading`, as described in the comment at the top of `sensor.js`.
- Keep every file you create in this folder.
- The student opens the page by double-clicking it, with no server and no internet. So don't load files with `fetch`, and play the sounds with an audio element.
